# Bayesian Network Structure Learning and Estimation Module
# Implements structure learning using MMHC (Max-Min Hill Climbing) and parameter estimation via BDeu scoring

import math
import networkx as nx
from collections import Counter, defaultdict
from typing import Tuple, Dict, Iterable, Optional
import pandas as pd

# pgmpy library for probabilistic graphical models
from pgmpy.estimators import PC, HillClimbSearch, BayesianEstimator, MmhcEstimator, K2Score, BicScore, BDeuScore
from pgmpy.sampling import BayesianModelSampling
from pgmpy.models import BayesianModel

import matplotlib.pyplot as plt

def create_bayes_net(data):
    """
    Learn Bayesian Network structure and estimate parameters from data.
    Uses MMHC (Max-Min Hill Climbing) algorithm for structure learning.
    """
    # Learn skeleton using Max-Min Hill Climbing algorithm with MMPC
    est = MmhcEstimator(data)  # Max-Min Hill Climb algorithm
    skeleton = est.mmpc(significance_level=0.05)
    
    # Score edges and find optimal DAG using Hill Climbing with BDeu scoring
    hc = HillClimbSearch(data)
    best_model = hc.estimate(
        tabu_length=10, 
        white_list=skeleton.to_directed().edges(), 
        scoring_method=BDeuScore(data)
    )
    
    # Extract edges and nodes from the learned structure
    edges = best_model.edges()
    nodes = best_model.nodes()
    
    # Create and fit BayesianModel with conditional probability distributions
    model = BayesianModel(list(edges))
    model.add_nodes_from(list(nodes))
    model.fit(data, complete_samples_only=False)
    
    # Return CPDs (Conditional Probability Distributions) and the trained model
    cpds = model.get_cpds()
    return cpds, model


def create_bayes_net_pdag(data):
    """
    Learn Bayesian Network using PC algorithm and return PDAG (Partially Directed Acyclic Graph).
    PC algorithm is constraint-based and uses conditional independence tests.
    """
    # Run PC algorithm to learn causal structure
    est = PC(data)
    
    # Step 1: Build undirected skeleton using conditional independence tests
    skel, seperating_sets = est.build_skeleton(significance_level=0.05)
    print("Undirected edges: ", skel.edges())
    
    # Step 2: Convert skeleton to PDAG by directing edges based on v-structures
    pdag = est.skeleton_to_pdag(skel, seperating_sets)
    print("PDAG edges:       ", pdag.edges())
    
    # Step 3: Convert PDAG to a complete DAG (directed acyclic graph)
    model = pdag.to_dag()
    print("DAG edges:        ", model.edges())
    
    return pdag


def plot_simple_bayes_net(id, model):
    """
    Visualize Bayesian Network structure as a directed graph.
    Nodes are arranged in a circular layout and edges represent dependencies.
    
    Args:
        id: Identifier for the network (for tracking purposes)
        model: BayesianModel object to visualize
        
    Returns:
        fig: Matplotlib figure object
        g: NetworkX DiGraph object
    """
    g = nx.DiGraph()
    
    # Extract edges and collect all node labels (variables)
    edges = list(model.edges)
    edge_labels = []
    for edge in edges:
        edge_labels = edge_labels + list(edge)
    
    # Get unique variable names, sorted alphabetically
    node_labels = sorted(list(set(edge_labels)))
    
    fig = plt.figure(figsize=(8, 6))
    
    # Handle case where there are no dependencies
    if len(node_labels) == 0:
        ax = plt.gca()
        ax.text(0, 0, 'no dependencies', horizontalalignment='center')
        ax.margins(0.1)
        plt.axis("off")
    else:  
        # Arrange nodes in circular layout with equal spacing
        deg = 2 * math.pi / len(node_labels)
        for t in range(len(node_labels)):
            # Calculate positions on unit circle
            pos_x = math.cos(t * deg + deg / 2)
            pos_y = math.sin(t * deg + deg / 2)
            g.add_node(node_labels[t], pos=(pos_x, pos_y))
        
        # Add edges to the graph
        g.add_edges_from(model.edges)
        
        # Configure visualization options
        options = {
            "font_size": 8,
            "node_size": 4000,
            "node_color": "white",
            "edgecolors": "black",
            "linewidths": 2,
            "width": 2,
        }
        
        # Draw network with stored positions
        pos = nx.get_node_attributes(g, 'pos')
        nx.draw(g, pos, with_labels=True, **options)
        
    plt.show()
    return fig, g

# from pgmpy.models import BayesianNetwork as BayesianModel  # 別名統一

def _fit_once(
    data: pd.DataFrame,
    significance_level: float = 0.05,
    tabu_length: int = 10,
    equivalent_sample_size: float = 10.0,
) -> BayesianModel:
    """
    Learn Bayesian Network structure and parameters in a single iteration.
    Uses MMHC algorithm for structure learning and BDeu score for edge evaluation.
    
    Args:
        data: Input DataFrame with variables as columns
        significance_level: Threshold for conditional independence tests
        tabu_length: Number of recent edges to exclude from search (prevents cycling)
        equivalent_sample_size: Hyperparameter for BDeu scoring function
        
    Returns:
        BayesianModel: Fitted model with learned structure and parameters
    """
    # Learn network skeleton using MMHC algorithm
    est = MmhcEstimator(data)
    skeleton = est.mmpc(significance_level=significance_level)
    
    # Use Hill Climbing to find best DAG from skeleton
    hc = HillClimbSearch(data)
    white_list = list(skeleton.to_directed().edges())
    
    # Estimate model structure with BDeu (Bayesian Dirichlet equivalent uniform) scoring
    best_model = hc.estimate(
        tabu_length=tabu_length,
        white_list=white_list,
        scoring_method=BDeuScore(data, equivalent_sample_size=equivalent_sample_size),
        show_progress=False
    )
    
    # Reconstruct as explicit BayesianModel and fit to data
    # (pgmpy's best_model output is model-like but we create explicit BayesianModel for consistency)
    model = BayesianModel(list(best_model.edges()))
    model.add_nodes_from(list(best_model.nodes()))
    model.fit(data, complete_samples_only=False)
    return model


def create_bayes_net_with_stability(
    data: pd.DataFrame,
    *,
    # Learning parameters
    significance_level: float = 0.05,
    tabu_length: int = 10,
    equivalent_sample_size: float = 10.0,
    # Subsampling configuration
    n_boot: int = 100,
    sample_frac: float = 0.8,           # Fraction of data to sample (1 - p_drop)
    random_state: Optional[int] = 0,
    treat_undirected_as_same: bool = False,  # If True, aggregate using {u,v} without direction
    progress: bool = False,
) -> Tuple[Iterable, BayesianModel, Dict, Dict]:
    """
    Learn Bayesian Network structure with edge stability estimation via subsampling.
    
    Uses bootstrap subsampling (sampling without replacement) to estimate how frequently
    each edge appears across different data samples. This provides a measure of robustness
    for the discovered edges - higher appearance probability indicates more reliable edges.
    
    Args:
        data: Input DataFrame with variables as columns
        significance_level: Threshold for conditional independence tests
        tabu_length: Number of recent edges to exclude from Hill Climbing search
        equivalent_sample_size: Hyperparameter for BDeu scoring
        n_boot: Number of bootstrap subsamples to generate
        sample_frac: Fraction of data to use in each subsample (0 < sample_frac <= 1)
        random_state: Seed for reproducibility; None for non-deterministic sampling
        treat_undirected_as_same: If True, merge bidirectional edges (u->v and v->u)
        progress: If True, display progress bar during subsampling iterations
        
    Returns:
        cpds: Conditional Probability Distributions from full-data model
        model: BayesianModel fitted on complete dataset
        edge_prob_directed: Dictionary mapping directed edges (u,v) to appearance probabilities
        edge_prob_undirected: Dictionary mapping undirected edges frozenset({u,v}) to probabilities
    """
    # Initialize random state parameter
    rng = None if random_state is None else random_state

    # Step 1: Learn model from full dataset (final model for output)
    model = _fit_once(
        data,
        significance_level=significance_level,
        tabu_length=tabu_length,
        equivalent_sample_size=equivalent_sample_size,
    )
    cpds = model.get_cpds()

    # Step 2: Bootstrap subsampling to estimate edge stability
    # Initialize counters to track edge appearances across subsamples
    directed_counts = Counter()   # Track directed edges: (u, v) -> count
    undirected_counts = Counter()  # Track undirected edges: frozenset({u, v}) -> count

    # Calculate subsample size from sampling fraction
    n = len(data)
    k = max(1, int(round(n * sample_frac)))
    index = data.index

    # Set up iteration with optional progress bar
    it = range(n_boot)
    if progress:
        try:
            from tqdm.auto import tqdm
            it = tqdm(it, desc="Sub-sampling", leave=False)
        except Exception:
            pass

    # Perform bootstrap iterations
    for b in it:
        # Sample without replacement (subsampling) from original data
        samp = data.loc[
            index.to_series().sample(n=k, replace=False, random_state=None if rng is None else (rng + b)).values
        ]

        try:
            # Fit model to subsample (with more lenient significance level for small samples)
            m_b = _fit_once(
                samp,
                significance_level=significance_level * 3,  # More lenient for small subsamples
                tabu_length=tabu_length,
                equivalent_sample_size=equivalent_sample_size,
            )
        except Exception:
            # Skip if model fitting fails due to small sample or numerical issues
            continue

        # Count edge appearances in both directed and undirected forms
        for u, v in m_b.edges():
            directed_counts[(u, v)] += 1
            undirected_counts[frozenset({u, v})] += 1

    # Normalize counts to probabilities (per-edge appearance frequency)
    edge_prob_directed = {e: c / max(1, n_boot) for e, c in directed_counts.items()}
    edge_prob_undirected = {e: c / max(1, n_boot) for e, c in undirected_counts.items()}

    # Optional: Treat both directions as same edge type
    # (Sum probabilities of (u,v) and (v,u) for undirected interpretation)
    if treat_undirected_as_same:
        # Aggregate bidirectional edges for undirected interpretation
        tmp = defaultdict(float)
        for (u, v), p in edge_prob_directed.items():
            # Use sorted tuple as key to merge u->v and v->u
            key = tuple(sorted((u, v)))
            tmp[key] = min(1.0, tmp[key] + p)
        edge_prob_directed = dict(tmp)

    return cpds, model, edge_prob_directed, edge_prob_undirected